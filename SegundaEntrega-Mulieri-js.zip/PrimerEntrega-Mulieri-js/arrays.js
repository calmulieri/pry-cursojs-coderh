let array1 = ['carlos', 'pedro', 'jose']
console.log(array1)
let indice = array1.push('monica', 'graciela')
console.log(array1)
console.log(indice)
let borrado = array1.pop()
console.log(array1)
indice = array1.length
console.log(borrado)
console.log(array1)
console.log(indice)

 
