const titulo = document.getElementById("titu1")
const porclases = document.getElementsByClassName("nutrirse")
console.dir(titulo)
console.dir(porclases)
